export FLASK_APP=core
flask run --host=0.0.0.0
