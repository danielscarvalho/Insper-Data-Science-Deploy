# A very simple Flask Hello World app for you to get started with...

from flask import Flask
from flask import request
import os
import platform
import sys
from datetime import datetime
from flask import send_from_directory
import insperds

# Cria instância do Flask, põe o serviço/processo no ar
app = Flask(__name__)

@app.route('/')
def hello_world():
    now = str(datetime.now())
    return 'Hello from Flask by Insper DS GCP App Engine - Serverless! - ' \
            + now \
            + " - " \
            + platform.platform() \
            + " - " \
            + sys.version

@app.route('/core')
def core():
    now = str(datetime.now())
    return 'Vai Corinthians!! - ' + now

@app.route('/quadrado/<a>/<b>')
def quadrado(a, b=2):
    return str(float(a) ** float(b))

@app.route('/add/<a>/<b>')
def add(a, b):
    return str(float(a) + float(b))

@app.route('/area')
def myarea():
  altura = request.args.get('altura', default = 0, type = float)
  largura = request.args.get('largura', default = 0, type = float)
  comprimento = request.args.get('comprimento', default = -1, type = float)
  
  if (comprimento < 0):
        return str(altura*largura)
  else:
        return str(altura*largura*comprimento)

@app.route('/query/<text>')
def query(text):
    return insperds.ddgquery(text)
    
@app.route('/bitcoins')
def btc():
    return insperds.bitcoins()
    
@app.route('/ethereum')
def ether():
    return insperds.ethereum()
    
@app.route('/weather/<lat>/<lon>')
def weather(lat, lon):
    return insperds.weather(lat, lon)

@app.route('/favicon.ico')
def favicon():
    return send_from_directory(os.path.join(app.root_path, 'static'),
                               'favicon.ico', mimetype='image/vnd.microsoft.icon')
