# Build and upload Docker image to Google Cloud Build to:
# - Build a container image from the local Python Flask app’s code and Dockerfile.
# - Push that image to Google Container Registry (GCR) under a specific tag.

gcloud builds submit --tag gcr.io/insper-deploy-2025/insper-flask-ds-gcp

# This command deploys the container image just built to Google Cloud Run from GCR, 
# making the Python Flask app available as a managed service with a public URL with TLS.

gcloud run deploy insper-flask-ds-gcp \
  --image gcr.io/insper-deploy-2025/insper-flask-ds-gcp \
  --region us-east1 \
  --platform managed \
  --allow-unauthenticated


