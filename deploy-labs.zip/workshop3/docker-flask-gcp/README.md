# Insper-Flask-DS-Server
Insper Flask Data Science Server API
